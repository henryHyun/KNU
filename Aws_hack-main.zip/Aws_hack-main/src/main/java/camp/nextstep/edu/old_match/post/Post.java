package camp.nextstep.edu.old_match.post;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import camp.nextstep.edu.old_match.user.domain.UserPost;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "post")
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Post {
	@Id
	@GeneratedValue
	private Long id;

	@Column(name = "cost")
	Long cost;

	@Column(name="accept")
	Boolean accept;

	@Column(name="start_time")
	LocalDateTime startTime;

	@Column(name="end_time")
	LocalDateTime endTime;

	@Column(name="content")
	String content;

	@OneToMany(mappedBy = "post")
	private List<UserPost> userPost = new ArrayList<>();


}
