package camp.nextstep.edu.old_match;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OldMatchApplication {

	public static void main(String[] args) {
		SpringApplication.run(OldMatchApplication.class, args);
	}

}
