package camp.nextstep.edu.old_match.user.domain;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Table(name = "users")
public class User {
	@Id
	@GeneratedValue
	private Long id;

	@Column(name="name")
	private String name;

	@Column(name = "phone_number")
	private String phoneNumber;

	@Column(name = "password")
	private String password;

	@Column(name="is_helper")
	private Boolean isHelper;

	@Column(name="grade")
	private int grade;

	@Column(name="certification")
	private String certification;

	@Column(name = "region")
	private String region;

	@Column(name="profile_image")
	private String profileImage;

	@Column(name="intro")
	private String intro;

	@Column(name="career")
	private String career;

	@OneToMany(mappedBy = "writer")
	private List<UserPost> write_post = new ArrayList<>();

	@OneToMany(mappedBy = "helper")
	private List<UserPost> help_applicant = new ArrayList<>();
}
