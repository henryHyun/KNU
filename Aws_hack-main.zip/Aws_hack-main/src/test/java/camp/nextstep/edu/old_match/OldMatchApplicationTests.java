package camp.nextstep.edu.old_match;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OldMatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
