package com.techwave.olol;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OlolApplicationTest {

	@Test
	void contextLoads() {
	}
}
