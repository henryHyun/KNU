---
name: Refactoring template
about: Refactoring project
title: "♻️ [Refactor]"
labels: ''
assignees: ''

---

## ♻️ 이슈 체크리스트

- [x] 이슈 제목: [Refactor] '리팩토링 내용 상세'
- [ ] Assignees, Label을 붙여주세요.

## 📄 리팩토링 개요

- 리팩토링 내용 요약 설명

## 📝 리팩토링 상세 내용

- 리팩토링 관련 상세 내용 작성

## ✅ TODO

<!-- 이슈를 태깅하셔도 됩니다! -->

- [ ] 이거 하려면 이런 걸 해야해
- [ ] 이것도 해야할 것 같아

## 📍 레퍼런스

<!-- 참고할 레퍼런스가 있다면 작성해 주세요. -->