---
name: Bug report
about: Create a report to help us improve
title: "\U0001F6A8 [Bug] "
labels: ''
assignees: ''

---

## 🚨 이슈 체크리스트

- [x] 이슈 제목: [BUG] '버그 내용 상세'
- [ ] Assignees, Label을 붙여주세요.

## 🐛 버그 개요

- 이런 버그가 발생했습니다.

## 🐞 버그 상세 내용

- 그래서 이런 문제가 발생합니다.
- 이런 식으로 재현이 돼
- 이 파일 or 코드에서 문제가 발생한 거 같아

## ✅ TODO

- [ ] 이거 하려면 이런 걸 해야해
- [ ] 이것도 해야할 것 같아